package com.amdocs.DoctorConsultation.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Doctor {
	
	@Id
	private long DoctorId;
	private String DoctorName;
	private String DoctorEmail;
	private int DoctorAge;
	public long getDoctorId() {
		return DoctorId;
	}
	public void setDoctorId(long doctorId) {
		DoctorId = doctorId;
	}
	public String getDoctorName() {
		return DoctorName;
	}
	public void setDoctorName(String doctorName) {
		DoctorName = doctorName;
	}
	public String getDoctorEmail() {
		return DoctorEmail;
	}
	public void setDoctorEmail(String doctorEmail) {
		DoctorEmail = doctorEmail;
	}
	public int getDoctorAge() {
		return DoctorAge;
	}
	public void setDoctorAge(int doctorAge) {
		DoctorAge = doctorAge;
	}
	
	
}
