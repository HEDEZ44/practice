package com.amdocs.DoctorConsultation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DoctorConsultationApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoctorConsultationApplication.class, args);
	}

}
