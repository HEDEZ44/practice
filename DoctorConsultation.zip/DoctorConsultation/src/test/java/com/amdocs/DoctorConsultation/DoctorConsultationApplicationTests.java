package com.amdocs.DoctorConsultation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoctorConsultationApplicationTests {

	@Test
	void contextLoads() {
	}

}
